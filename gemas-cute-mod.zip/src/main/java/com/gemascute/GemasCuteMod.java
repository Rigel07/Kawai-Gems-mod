package com.gemascute;

import com.gemascute.registry.ModBlocks;
import com.gemascute.registry.ModCreativeTabs;
import com.gemascute.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(GemasCuteMod.MODID)
public class GemasCuteMod {
    public static final String MODID = "gemascute";

    public GemasCuteMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModBlocks.BLOCK_ITEMS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
