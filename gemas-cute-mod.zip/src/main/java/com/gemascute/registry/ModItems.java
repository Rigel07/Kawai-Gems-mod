package com.gemascute.registry;

import com.gemascute.GemasCuteMod;
import com.gemascute.item.LunitaWandItem;
import com.gemascute.item.PinkitaSwordItem;
import com.gemascute.item.SolitaAmuletItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ShovelItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GemasCuteMod.MODID);

    // ---- Gemas ----
    public static final RegistryObject<Item> PINKITA = gem("pinkita", Rarity.COMMON);
    public static final RegistryObject<Item> MENTITA = gem("mentita", Rarity.COMMON);
    public static final RegistryObject<Item> JELLITA = gem("jellita", Rarity.UNCOMMON);
    public static final RegistryObject<Item> ESTRELLITA = gem("estrellita", Rarity.UNCOMMON);
    public static final RegistryObject<Item> LUNITA = gem("lunita", Rarity.RARE);
    public static final RegistryObject<Item> SOLITA = gem("solita", Rarity.RARE);
    public static final RegistryObject<Item> BERRITA = gem("berrita", Rarity.EPIC);

    // ---- Mentita: fertilizante (funciona como harina de hueso) ----
    public static final RegistryObject<Item> MENTITA_DUST = ITEMS.register("mentita_dust",
            () -> new BoneMealItem(new Item.Properties()));

    // ---- Pinkita: herramientas ----
    public static final RegistryObject<Item> PINKITA_SWORD = ITEMS.register("pinkita_sword",
            () -> new PinkitaSwordItem(ModTiers.PINKITA, 3, -2.4F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_PICKAXE = ITEMS.register("pinkita_pickaxe",
            () -> new PickaxeItem(ModTiers.PINKITA, 1, -2.8F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_AXE = ITEMS.register("pinkita_axe",
            () -> new AxeItem(ModTiers.PINKITA, 5.0F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_SHOVEL = ITEMS.register("pinkita_shovel",
            () -> new ShovelItem(ModTiers.PINKITA, 1.5F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> PINKITA_HOE = ITEMS.register("pinkita_hoe",
            () -> new HoeItem(ModTiers.PINKITA, -1, -1.0F, new Item.Properties()));

    // ---- Lunita: varita de salto lunar ----
    public static final RegistryObject<Item> LUNITA_WAND = ITEMS.register("lunita_wand",
            () -> new LunitaWandItem(new Item.Properties().durability(60).rarity(Rarity.RARE)));

    // ---- Solita: amuleto ----
    public static final RegistryObject<Item> SOLITA_AMULET = ITEMS.register("solita_amulet",
            () -> new SolitaAmuletItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    // ---- Berrita: corazon que da vida extra durante un buen rato ----
    public static final RegistryObject<Item> BERRITA_HEART = ITEMS.register("berrita_heart",
            () -> new Item(new Item.Properties().rarity(Rarity.EPIC).food(new FoodProperties.Builder()
                    .nutrition(6)
                    .saturationMod(1.0F)
                    .alwaysEat()
                    .effect(() -> new MobEffectInstance(MobEffects.HEALTH_BOOST, 6000, 2), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 200, 1), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 1), 1.0F)
                    .build())));

    private static RegistryObject<Item> gem(String name, Rarity rarity) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().rarity(rarity)));
    }
}
