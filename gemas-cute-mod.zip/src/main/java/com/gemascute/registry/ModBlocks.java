package com.gemascute.registry;

import com.gemascute.GemasCuteMod;
import com.gemascute.block.JellyBlock;
import java.util.function.Supplier;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, GemasCuteMod.MODID);
    /** Los items de bloque van aparte para no mezclar registros. */
    public static final DeferredRegister<Item> BLOCK_ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, GemasCuteMod.MODID);

    // ---- Pinkita (rosa, comun) ----
    public static final RegistryObject<Block> PINKITA_ORE = ore("pinkita_ore", false, 3.0F, 0, 1, 3, MapColor.COLOR_PINK);
    public static final RegistryObject<Block> DEEPSLATE_PINKITA_ORE = ore("deepslate_pinkita_ore", true, 3.0F, 0, 1, 3, MapColor.COLOR_PINK);
    public static final RegistryObject<Block> PINKITA_BLOCK = gemBlock("pinkita_block", 4.0F, 0, MapColor.COLOR_PINK, SoundType.AMETHYST);

    // ---- Mentita (verde menta, comun) ----
    public static final RegistryObject<Block> MENTITA_ORE = ore("mentita_ore", false, 3.0F, 0, 1, 3, MapColor.EMERALD);
    public static final RegistryObject<Block> DEEPSLATE_MENTITA_ORE = ore("deepslate_mentita_ore", true, 3.0F, 0, 1, 3, MapColor.EMERALD);
    public static final RegistryObject<Block> MENTITA_BLOCK = gemBlock("mentita_block", 4.0F, 0, MapColor.EMERALD, SoundType.AMETHYST);

    // ---- Jellita (azul bebe, poco comun) ----
    public static final RegistryObject<Block> JELLITA_ORE = ore("jellita_ore", false, 3.0F, 0, 2, 4, MapColor.COLOR_LIGHT_BLUE);
    public static final RegistryObject<Block> DEEPSLATE_JELLITA_ORE = ore("deepslate_jellita_ore", true, 3.0F, 0, 2, 4, MapColor.COLOR_LIGHT_BLUE);
    /** Bloque que rebota. */
    public static final RegistryObject<Block> JELLITA_BLOCK = block("jellita_block",
            () -> new JellyBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_LIGHT_BLUE)
                    .strength(1.0F)
                    .sound(SoundType.SLIME_BLOCK)));

    // ---- Estrellita (amarillo crema, rara, brilla) ----
    public static final RegistryObject<Block> ESTRELLITA_ORE = ore("estrellita_ore", false, 3.5F, 6, 3, 6, MapColor.COLOR_YELLOW);
    public static final RegistryObject<Block> DEEPSLATE_ESTRELLITA_ORE = ore("deepslate_estrellita_ore", true, 3.5F, 6, 3, 6, MapColor.COLOR_YELLOW);
    public static final RegistryObject<Block> ESTRELLITA_BLOCK = gemBlock("estrellita_block", 4.0F, 12, MapColor.COLOR_YELLOW, SoundType.AMETHYST);
    public static final RegistryObject<Block> ESTRELLITA_LAMP = block("estrellita_lamp",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_YELLOW)
                    .strength(1.5F)
                    .sound(SoundType.GLASS)
                    .lightLevel(state -> 15)));

    // ---- Lunita (violeta, muy rara) ----
    public static final RegistryObject<Block> LUNITA_ORE = ore("lunita_ore", false, 4.0F, 3, 4, 8, MapColor.COLOR_PURPLE);
    public static final RegistryObject<Block> DEEPSLATE_LUNITA_ORE = ore("deepslate_lunita_ore", true, 4.0F, 3, 4, 8, MapColor.COLOR_PURPLE);
    public static final RegistryObject<Block> LUNITA_BLOCK = gemBlock("lunita_block", 5.0F, 4, MapColor.COLOR_PURPLE, SoundType.AMETHYST);

    // ---- Solita (naranja sol, muy rara, solo en montanas altas) ----
    public static final RegistryObject<Block> SOLITA_ORE = ore("solita_ore", false, 4.0F, 5, 5, 9, MapColor.COLOR_ORANGE);
    public static final RegistryObject<Block> DEEPSLATE_SOLITA_ORE = ore("deepslate_solita_ore", true, 4.0F, 5, 5, 9, MapColor.COLOR_ORANGE);
    public static final RegistryObject<Block> SOLITA_BLOCK = gemBlock("solita_block", 5.0F, 8, MapColor.COLOR_ORANGE, SoundType.AMETHYST);

    // ---- Berrita (rojo frambuesa, la mas rara, en lo mas profundo) ----
    public static final RegistryObject<Block> BERRITA_ORE = ore("berrita_ore", false, 5.0F, 0, 7, 12, MapColor.CRIMSON_NYLIUM);
    public static final RegistryObject<Block> DEEPSLATE_BERRITA_ORE = ore("deepslate_berrita_ore", true, 5.0F, 0, 7, 12, MapColor.CRIMSON_NYLIUM);
    public static final RegistryObject<Block> BERRITA_BLOCK = gemBlock("berrita_block", 6.0F, 0, MapColor.CRIMSON_NYLIUM, SoundType.AMETHYST);

    private static RegistryObject<Block> ore(String name, boolean deepslate, float hardness, int light,
                                             int xpMin, int xpMax, MapColor color) {
        return block(name, () -> new DropExperienceBlock(BlockBehaviour.Properties.of()
                .mapColor(color)
                .strength(deepslate ? hardness + 1.5F : hardness, 3.0F)
                .requiresCorrectToolForDrops()
                .sound(deepslate ? SoundType.DEEPSLATE : SoundType.STONE)
                .lightLevel(state -> light),
                UniformInt.of(xpMin, xpMax)));
    }

    private static RegistryObject<Block> gemBlock(String name, float hardness, int light, MapColor color, SoundType sound) {
        return block(name, () -> new Block(BlockBehaviour.Properties.of()
                .mapColor(color)
                .strength(hardness, 6.0F)
                .requiresCorrectToolForDrops()
                .sound(sound)
                .lightLevel(state -> light)));
    }

    private static RegistryObject<Block> block(String name, Supplier<Block> supplier) {
        RegistryObject<Block> object = BLOCKS.register(name, supplier);
        BLOCK_ITEMS.register(name, () -> new BlockItem(object.get(), new Item.Properties()));
        return object;
    }
}
