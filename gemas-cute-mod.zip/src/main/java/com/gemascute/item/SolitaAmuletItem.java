package com.gemascute.item;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Amuleto de Solita: en la barra rapida (o la mano izquierda) da resistencia al fuego y prisa. */
public class SolitaAmuletItem extends Item {
    public SolitaAmuletItem(Properties properties) {
        super(properties);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (!level.isClientSide && entity instanceof Player player
                && (slot < 9 || slot == 40) && level.getGameTime() % 40 == 0) {
            player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 100, 0, true, false, true));
            player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 100, 0, true, false, true));
        }
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
