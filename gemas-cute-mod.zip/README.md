# Gemas Cute (Forge 1.20.1)

Siete minerales nuevos, todos pastel y con forma monísima (corazón, trébol, gominola, estrella, luna, sol y frambuesa).
Cada uno tiene su propia función y su propia rareza.

| Mineral | Color | Dónde / rareza | Para qué sirve |
|---|---|---|---|
| **Pinkita** | rosa | Muy común, y -16 a 96 | Juego de herramientas completo (un poco mejor que hierro). La espada suelta corazoncitos al golpear |
| **Mentita** | verde menta | Común, y -32 a 64 | Polvo de Mentita: funciona como harina de hueso (1 gema = 3 polvos) |
| **Jellita** | azul bebé | Poco común, y -48 a 32 | Bloque de Jellita: rebota como una gominola y no hace daño al caer (agáchate para no rebotar) |
| **Estrellita** | amarillo crema | Rara, y -64 a 16 | Lámpara de Estrellita (luz máxima). La mena y su bloque también brillan |
| **Lunita** | violeta | Muy rara, bajo y -8 | Varita de Lunita: clic derecho = salto lunar, teletransporte corto hacia donde miras |
| **Solita** | naranja sol | Muy rara, solo en montañas altas (y 64 a 180) | Amuleto de Solita: en la barra rápida o mano izquierda da resistencia al fuego y prisa |
| **Berrita** | rojo frambuesa | La más rara, en lo más profundo (y -64 a -24) | Corazón de Berrita (2 gemas + manzana): vida extra 5 minutos, regeneración y absorción |

Herramienta necesaria: Pinkita, Mentita y Jellita con pico de piedra; Estrellita, Lunita y Solita con hierro; Berrita con diamante.
Todas las gemas se pueden guardar en bloques (9 gemas) y sacar de nuevo. Las menas dan más gemas con Fortuna y se pueden recoger con Toque de seda.

## Compilar con GitHub
1. Sube **todo** el contenido de esta carpeta a la raíz de un repositorio (`settings.gradle` y `build.gradle` deben verse nada más abrir el repo).
2. El archivo `.github/workflows/build.yml` es una carpeta oculta: si no se sube, créalo a mano ("Add file" > "Create new file", nombre `.github/workflows/build.yml`).
3. Actions > último workflow > Artifacts > `gemas-cute-jar`. Dentro está `gemascute-1.0.0.jar` para la carpeta `mods` de Forge 1.20.1.
